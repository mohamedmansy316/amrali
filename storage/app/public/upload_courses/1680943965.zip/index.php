<?php
/*
Created by mohamed ramadan
Email:mr319242@gmail.com
Phone:01011642731

*/

$pagetitle = "قناة الجواهرجية";
ob_start();


session_start();

//echo $_SERVER['HTTP_USER_AGENT'];


include "init.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST["login"])){

    $username =  $_POST["username"];
    $userpass = $_POST["password"];
    $userip   = $_POST["userip"];

    $stmt = $connect->prepare("SELECT user_name, user_password, user_ip FROM users WHERE user_name=?
  AND user_password=? AND user_ip=? AND user_approval=1");
    $stmt->execute(array($username, $userpass , $userip));
    $data = $stmt->fetch();
    $count = $stmt->rowcount();
    if ($count > 0) {
        if(!empty($_POST["remember"]))
        {
            setcookie ("member_login",$username,time()+ (10 * 365 * 24 * 60 * 60));
            setcookie ("member_password",$userpass,time()+ (10 * 365 * 24 * 60 * 60));
            $_SESSION['user']    = $username;
               header('Location:table1.php');
        exit();
        }
        else
        {
            if(isset($_COOKIE["member_login"]))
            {
                setcookie ("member_login","");
            }
            if(isset($_COOKIE["member_password"]))
            {
                setcookie ("member_password","");
            }
        $_SESSION['user']    = $username;

        header('Location:table1.php');
        exit();

    }

    }}else{

        $username=$_POST["username"];
        $userpass = $_POST["password"];
        $address=$_POST["address"];
        $mobile = $_POST["mobile"];
        $userip =     $_POST["userip"];
        $stmt = $connect->prepare("SELECT * FROM users WHERE user_name=?");
        $stmt->execute(array($username));
        $users = $stmt->fetch();
        $count = $stmt->rowCount();
        if($count > 0){?>
            <div class="container">
                <div class="data">
                    <h2 class="alert alert-danger"> هذا المستخدم موجود بالفعل ادخل اسم مستخدم اخر </h2>
                </div>
            </div>
         <?php
        }else{
            $stmt = $connect->prepare("INSERT INTO users (user_name,user_password,user_mobile,user_address,user_ip)
 VALUES (:zname,:zpass,:zmobile,:zaddress,:zip)");
            $stmt->execute(array(
                "zname" => $username,
                "zpass" => $userpass,
                "zmobile" => $mobile,
                "zaddress" => $address,
                "zip" => $userip

            ));
            if ($stmt){?>
                <div class="container">
                    <div class="data">
                        <h2 class="alert alert-success"> تم انشاء الحساب بنجاح تواصل مع الادارة الان لسرعة التفعيل علي رقم 1099755774(20+) </h2>
                    </div>
                </div>
                <?php

            }
        }




    }

}
?>

 <!-- START LOGIN FORM -->

    <div class="login">

        <div class="container">

            <div class="row">
<div class="col-md-12 col-lg-6">
    <div class="info2"> للاشتراك في قناة الجواهرجية قم بإنشاء حساب جديد وتواصل معنا علي  

        <div class="social">
            <h6> <a href="mailto:mr.mohamedimam@yahoo.com"><i class="fa fa-envelope"></i> mr.mohamedimam@yahoo.com </a> </h6>
            <h6> <a href="https://api.whatsapp.com/send?phone=+201099755774" target="_blank"> <i class="fa fa-whatsapp"></i> +201099755774   </a></h6>
        </div>
    </div>
</div>
      <div class="col-md-12 col-lg-6">
          <div class="info">




              <div class="myform">
                  <!-- START LOGIN PAGE -->
                  <form class="form-group login_form" method="POST"  action="<?php echo $_SERVER["PHP_SELF"] ?>">
                      <h1> تسجيل دخول  </h1>
                      
                      <?php
                      // get ip address
                      // check for ip address shared internet
                      /*
                      if (!empty($_SERVER['HTTP_CLIENT_IP'])){
                          $ip = $_SERVER['HTTP_CLIENT_IP'];
                      }
                      elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
                          // check for ip address proxy server
                          $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
                      }else{
                          $ip = $_SERVER['REMOTE_ADDR'];
                      }
                      */

                      $userip = sha1('xzr4'.$_SERVER['HTTP_USER_AGENT'].'f8k2');

                      ?>

                      <div class="input_box">

                          <label> اسم المستخدم </label>
                        <input type="hidden" name="userip" value="<?php echo $userip?>">
                          <input class="form-control" type="text" name="username" autocomplete="off" />

                      </div>

                      <div class="input_box">
                          <label>كلمة السر</label>

                          <input class="form-control" type="password" name="password"/>
                      </div>
                      <div class="input_box">
                          <label for="remember-me">تذكرنى </label>
                          <input type="checkbox" name="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?> />

                      </div>


                      <input class="btn btn-primary" name="login" type="submit" value="تسجيل دخول" />
                      <div class="links">
                          <span data-class=".signup_form"> انشاء حساب جديد </span> |
                          <span data-class=".login_form"> تسجبل دخول </span>
                          
                      </div>

                  </form>

                  <!-- END LOGIN PAGE -->
                  <!-- START SIGNUP PAGE -->
                  <form class="form-group signup_form" method="POST"  action="<?php echo $_SERVER["PHP_SELF"] ?>">
                      <h1> انشاء حساب </h1>
<?php

$userip = sha1('xzr4'.$_SERVER['HTTP_USER_AGENT'].'f8k2');


?>
                      <div class="input_box">

                          <label> اسم المستخدم </label>
                           <input name="userip" type="hidden" value="<?php echo $userip ?>">
                          <input class="form-control" type="text" name="username" autocomplete="off" />

                      </div>
                      <div class="input_box">

                          <label> رقم الموبايل </label>

                          <input class="form-control" type="text" name="mobile" autocomplete="off" />

                      </div>
                      <div class="input_box">

                          <label>  العنوان </label>

                          <input class="form-control" type="text" name="address" autocomplete="off" />

                      </div>
                      <div class="input_box">
                          <label>كلمة السر</label>

                          <input class="form-control" type="password" name="password"/>
                      </div>


                      <input class="btn btn-primary" type="submit" value=" انشاء حساب" />
                      <div class="links">
                          <span data-class=".signup_form"> انشاء حساب جديد </span> |
                          <span data-class=".login_form"> تسجبل دخول </span>
                      </div>

                  </form>



                  <!-- END sIGNUP PAGE -->


              </div>









          </div>
      </div>

            </div>

        </div>

    </div>

<!-- END LOGIN FORM -->

    <!-- END FOOTER -->
<?php

include $tem."footer.php";
ob_end_flush();
?>
<?php

ob_end_flush();